package nathan.dbentity

object Protocol {

  object UserTypeConst {
    val common = "common"
    val admin = "admin"
  }

  object DefaultAuth {
    val auth = "qazwsxedc"
  }

  val storeAgentMachine = "storeAgentMachine"
}
