package nathan.service.cpu

trait CpuPercTrait {

}
